package test;
import java.util.Scanner; 

public class Program
{
	private static Scanner in = new Scanner(System.in);
		
	public static void main(String[] args)	
	{		
		while(true)
		{
			String question = in.nextLine();
			if(question.contains("weather"))			
					Utility.showWeather("Bangalore");	
				
			else if(question.contains("news"))
			{
				Utility.showNews();
			}
			
			else
			{
				BotUtility bot = new BotUtility();
				bot.Talk(question);
			}			
		}
	}
}