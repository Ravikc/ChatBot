package test;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import org.alicebot.ab.Bot;
import org.alicebot.ab.Chat;

public class BotUtility
{
	public void Talk(String question)
	{
		ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		PrintStream dump = new PrintStream(outputStream);
		PrintStream old = System.out;
		
		//redirect library output to the dump stream
		System.setOut(dump);
		
		String botname="test";
		String path="c:/ab"; 
		Bot bot = new Bot(botname, path); 
		Chat chatSession = new Chat(bot); 
	
		
		String response = chatSession.multisentenceRespond(question); 
	
		System.out.flush();
		System.setOut(old);
		
		System.out.println(response); 
	}
}
